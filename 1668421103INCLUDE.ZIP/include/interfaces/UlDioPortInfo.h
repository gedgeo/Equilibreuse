/*
 * UlDioPortInfo.h
 *
 *     Author: Measurement Computing Corporation
 */

#ifndef INTERFACES_ULDIOPORTINFO_H_
#define INTERFACES_ULDIOPORTINFO_H_

namespace ul
{

class UlDioPortInfo
{
public:
	virtual ~UlDioPortInfo() {};
};

} /* namespace ul */

#endif /* INTERFACES_ULDIOPORTINFO_H_ */
